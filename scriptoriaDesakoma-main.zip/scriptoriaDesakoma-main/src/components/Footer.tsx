import { Link } from 'react-router-dom';
import { Film, Mail, Github, Twitter } from 'lucide-react';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="w-full bg-primary text-primary-foreground py-16">
      <div className="max-w-[100rem] mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Film className="w-8 h-8" />
              <span className="font-heading text-2xl">FilmAI</span>
            </div>
            <p className="font-paragraph text-sm text-primary-foreground/80">
              Professional AI-powered film pre-production tools for modern filmmakers
            </p>
          </div>

          <div>
            <h3 className="font-heading text-lg mb-4">Tools</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/script-generator" className="font-paragraph text-sm text-primary-foreground/80 hover:text-primary-foreground transition-colors">
                  Script Generator
                </Link>
              </li>
              <li>
                <Link to="/character-generator" className="font-paragraph text-sm text-primary-foreground/80 hover:text-primary-foreground transition-colors">
                  Character Generator
                </Link>
              </li>
              <li>
                <Link to="/scene-breakdown" className="font-paragraph text-sm text-primary-foreground/80 hover:text-primary-foreground transition-colors">
                  Scene Breakdown
                </Link>
              </li>
              <li>
                <Link to="/shot-list-generator" className="font-paragraph text-sm text-primary-foreground/80 hover:text-primary-foreground transition-colors">
                  Shot List Generator
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-heading text-lg mb-4">Resources</h3>
            <ul className="space-y-2">
              <li>
                <a href="#documentation" className="font-paragraph text-sm text-primary-foreground/80 hover:text-primary-foreground transition-colors">
                  Documentation
                </a>
              </li>
              <li>
                <a href="#tutorials" className="font-paragraph text-sm text-primary-foreground/80 hover:text-primary-foreground transition-colors">
                  Tutorials
                </a>
              </li>
              <li>
                <a href="#support" className="font-paragraph text-sm text-primary-foreground/80 hover:text-primary-foreground transition-colors">
                  Support
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-heading text-lg mb-4">Connect</h3>
            <div className="flex gap-4">
              <a href="#mail" className="text-primary-foreground/80 hover:text-primary-foreground transition-colors">
                <Mail className="w-5 h-5" />
              </a>
              <a href="#github" className="text-primary-foreground/80 hover:text-primary-foreground transition-colors">
                <Github className="w-5 h-5" />
              </a>
              <a href="#twitter" className="text-primary-foreground/80 hover:text-primary-foreground transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-primary-foreground/20 pt-8">
          <p className="font-paragraph text-sm text-primary-foreground/60 text-center">
            © {currentYear} FilmAI. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
