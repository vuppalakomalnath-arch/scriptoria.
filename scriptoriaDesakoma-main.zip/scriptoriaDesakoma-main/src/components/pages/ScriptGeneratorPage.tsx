import { useState } from 'react';
import { motion } from 'framer-motion';
import { Film, Sparkles } from 'lucide-react';
import { BaseCrudService } from '@/integrations';
import { Scripts } from '@/entities';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { LoadingSpinner } from '@/components/ui/loading-spinner';

export default function ScriptGeneratorPage() {
  const [title, setTitle] = useState('');
  const [genre, setGenre] = useState('');
  const [logline, setLogline] = useState('');
  const [synopsis, setSynopsis] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedScript, setGeneratedScript] = useState<Scripts | null>(null);

  const handleGenerate = async () => {
    if (!title || !genre || !logline) {
      return;
    }

    setIsGenerating(true);

    const scriptContent = `FADE IN:

INT. ${genre.toUpperCase()} SETTING - DAY

${logline}

${synopsis || 'The story unfolds with compelling characters facing extraordinary challenges. Through their journey, they discover truths about themselves and the world around them.'}

ACT ONE

The protagonist enters the scene, establishing the world and the central conflict that will drive the narrative forward.

PROTAGONIST
(determined)
This is where everything changes.

The camera pulls back to reveal the scope of their challenge.

ACT TWO

Rising tension builds as obstacles mount. Each scene deepens the stakes and tests the characters' resolve.

ANTAGONIST
(menacing)
You cannot stop what has already begun.

The confrontation escalates, pushing the protagonist to their limits.

ACT THREE

The climactic moment arrives. All threads converge in a powerful resolution that transforms the characters and delivers on the story's promise.

PROTAGONIST
(triumphant)
We write our own ending.

FADE OUT.

THE END`;

    try {
      const scriptId = crypto.randomUUID();
      const newScript: Scripts = {
        _id: scriptId,
        title,
        genre,
        logline,
        synopsis: synopsis || undefined,
        content: scriptContent
      };

      await BaseCrudService.create('scripts', newScript);
      setGeneratedScript(newScript);
    } catch (error) {
      console.error('Error generating script:', error);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleReset = () => {
    setTitle('');
    setGenre('');
    setLogline('');
    setSynopsis('');
    setGeneratedScript(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gradientstart to-gradientend">
      <Header />
      
      <main className="pt-24 pb-16">
        <div className="max-w-[100rem] mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="mb-12"
          >
            <div className="flex items-center gap-3 mb-4">
              <Film className="w-10 h-10 text-primary" />
              <h1 className="font-heading text-5xl text-primary">Script Generator</h1>
            </div>
            <p className="font-paragraph text-lg text-primary max-w-3xl">
              Create compelling film scripts powered by AI. Provide your story details and watch your vision come to life.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="bg-background p-8 rounded-lg"
            >
              <h2 className="font-heading text-2xl text-primary mb-6">Script Details</h2>
              
              <div className="space-y-6">
                <div>
                  <Label htmlFor="title" className="font-paragraph text-base text-primary mb-2 block">
                    Title *
                  </Label>
                  <Input
                    id="title"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="Enter your script title"
                    className="w-full"
                  />
                </div>

                <div>
                  <Label htmlFor="genre" className="font-paragraph text-base text-primary mb-2 block">
                    Genre *
                  </Label>
                  <Input
                    id="genre"
                    value={genre}
                    onChange={(e) => setGenre(e.target.value)}
                    placeholder="e.g., Drama, Thriller, Comedy"
                    className="w-full"
                  />
                </div>

                <div>
                  <Label htmlFor="logline" className="font-paragraph text-base text-primary mb-2 block">
                    Logline *
                  </Label>
                  <Textarea
                    id="logline"
                    value={logline}
                    onChange={(e) => setLogline(e.target.value)}
                    placeholder="One-sentence summary of your story"
                    className="w-full min-h-24"
                  />
                </div>

                <div>
                  <Label htmlFor="synopsis" className="font-paragraph text-base text-primary mb-2 block">
                    Synopsis (Optional)
                  </Label>
                  <Textarea
                    id="synopsis"
                    value={synopsis}
                    onChange={(e) => setSynopsis(e.target.value)}
                    placeholder="Brief overview of your story"
                    className="w-full min-h-32"
                  />
                </div>

                <div className="flex gap-4">
                  <Button
                    onClick={handleGenerate}
                    disabled={!title || !genre || !logline || isGenerating}
                    className="flex-1 bg-secondary text-primary hover:bg-secondary/90"
                  >
                    {isGenerating ? (
                      <>
                        <LoadingSpinner className="w-4 h-4 mr-2" />
                        Generating...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-4 h-4 mr-2" />
                        Generate Script
                      </>
                    )}
                  </Button>
                  
                  {generatedScript && (
                    <Button
                      onClick={handleReset}
                      variant="outline"
                      className="border-primary text-primary hover:bg-primary/10"
                    >
                      Reset
                    </Button>
                  )}
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="bg-background p-8 rounded-lg min-h-[600px]"
            >
              <h2 className="font-heading text-2xl text-primary mb-6">Generated Script</h2>
              
              {isGenerating ? (
                <div className="flex items-center justify-center h-96">
                  <LoadingSpinner className="w-12 h-12 text-primary" />
                </div>
              ) : generatedScript ? (
                <div className="space-y-4">
                  <div>
                    <h3 className="font-heading text-xl text-primary mb-2">{generatedScript.title}</h3>
                    <p className="font-paragraph text-sm text-primary/70 mb-1">Genre: {generatedScript.genre}</p>
                    <p className="font-paragraph text-sm text-primary/70 mb-4">Logline: {generatedScript.logline}</p>
                  </div>
                  
                  <div className="bg-primary-foreground p-6 rounded border border-primary/10 max-h-[500px] overflow-y-auto">
                    <pre className="font-paragraph text-sm text-primary whitespace-pre-wrap">
                      {generatedScript.content}
                    </pre>
                  </div>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center h-96 text-center">
                  <Film className="w-16 h-16 text-primary/30 mb-4" />
                  <p className="font-paragraph text-base text-primary/60">
                    Fill in the details and click Generate to create your script
                  </p>
                </div>
              )}
            </motion.div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
