import { useState } from 'react';
import { motion } from 'framer-motion';
import { Camera, Plus, Trash2 } from 'lucide-react';
import { BaseCrudService } from '@/integrations';
import { ShotLists } from '@/entities';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { LoadingSpinner } from '@/components/ui/loading-spinner';

export default function ShotListGeneratorPage() {
  const [shotNumber, setShotNumber] = useState('');
  const [shotSize, setShotSize] = useState('');
  const [angle, setAngle] = useState('');
  const [movement, setMovement] = useState('');
  const [description, setDescription] = useState('');
  const [isAdding, setIsAdding] = useState(false);
  const [shots, setShots] = useState<ShotLists[]>([]);

  const handleAdd = async () => {
    if (!shotNumber || !shotSize || !angle) {
      return;
    }

    setIsAdding(true);

    try {
      const newShot: ShotLists = {
        _id: crypto.randomUUID(),
        shotNumber: parseInt(shotNumber),
        shotSize,
        angle,
        movement: movement || 'Static',
        description: description || 'Captures the essential visual elements of the scene',
        _createdDate: new Date(),
        _updatedDate: new Date()
      };

      await BaseCrudService.create('shotlists', newShot);
      setShots([...shots, newShot]);
      
      setShotNumber('');
      setShotSize('');
      setAngle('');
      setMovement('');
      setDescription('');
    } catch (error) {
      console.error('Error creating shot:', error);
    } finally {
      setIsAdding(false);
    }
  };

  const handleDelete = async (shot: ShotLists) => {
    setShots(shots.filter(s => s._id !== shot._id));
    try {
      await BaseCrudService.delete('shotlists', shot._id);
    } catch (error) {
      console.error('Error deleting shot:', error);
      const allShots = await BaseCrudService.getAll<ShotLists>('shotlists');
      setShots(allShots.items);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gradientstart to-gradientend">
      <Header />
      
      <main className="pt-24 pb-16">
        <div className="max-w-[100rem] mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="mb-12"
          >
            <div className="flex items-center gap-3 mb-4">
              <Camera className="w-10 h-10 text-primary" />
              <h1 className="font-heading text-5xl text-primary">Shot List Generator</h1>
            </div>
            <p className="font-paragraph text-lg text-primary max-w-3xl">
              Create professional shot lists with detailed camera angles, movements, and technical specifications.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="lg:col-span-2 bg-background p-8 rounded-lg h-fit"
            >
              <h2 className="font-heading text-2xl text-primary mb-6">Add Shot</h2>
              
              <div className="space-y-6">
                <div>
                  <Label htmlFor="shotNumber" className="font-paragraph text-base text-primary mb-2 block">
                    Shot Number *
                  </Label>
                  <Input
                    id="shotNumber"
                    type="number"
                    value={shotNumber}
                    onChange={(e) => setShotNumber(e.target.value)}
                    placeholder="e.g., 1"
                    className="w-full"
                  />
                </div>

                <div>
                  <Label htmlFor="shotSize" className="font-paragraph text-base text-primary mb-2 block">
                    Shot Size *
                  </Label>
                  <Input
                    id="shotSize"
                    value={shotSize}
                    onChange={(e) => setShotSize(e.target.value)}
                    placeholder="e.g., Close-up, Wide, Medium"
                    className="w-full"
                  />
                </div>

                <div>
                  <Label htmlFor="angle" className="font-paragraph text-base text-primary mb-2 block">
                    Angle *
                  </Label>
                  <Input
                    id="angle"
                    value={angle}
                    onChange={(e) => setAngle(e.target.value)}
                    placeholder="e.g., Eye level, Low angle, High angle"
                    className="w-full"
                  />
                </div>

                <div>
                  <Label htmlFor="movement" className="font-paragraph text-base text-primary mb-2 block">
                    Movement (Optional)
                  </Label>
                  <Input
                    id="movement"
                    value={movement}
                    onChange={(e) => setMovement(e.target.value)}
                    placeholder="e.g., Pan, Tilt, Dolly, Static"
                    className="w-full"
                  />
                </div>

                <div>
                  <Label htmlFor="description" className="font-paragraph text-base text-primary mb-2 block">
                    Description (Optional)
                  </Label>
                  <Textarea
                    id="description"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Describe what happens in this shot"
                    className="w-full min-h-24"
                  />
                </div>

                <Button
                  onClick={handleAdd}
                  disabled={!shotNumber || !shotSize || !angle || isAdding}
                  className="w-full bg-secondary text-primary hover:bg-secondary/90"
                >
                  {isAdding ? (
                    <>
                      <LoadingSpinner className="w-4 h-4 mr-2" />
                      Adding...
                    </>
                  ) : (
                    <>
                      <Plus className="w-4 h-4 mr-2" />
                      Add Shot
                    </>
                  )}
                </Button>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="lg:col-span-3 bg-background p-8 rounded-lg min-h-[600px]"
            >
              <h2 className="font-heading text-2xl text-primary mb-6">Shot List</h2>
              
              {shots.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-96 text-center">
                  <Camera className="w-16 h-16 text-primary/30 mb-4" />
                  <p className="font-paragraph text-base text-primary/60">
                    No shots yet. Add your first shot to get started.
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {shots.sort((a, b) => (a.shotNumber || 0) - (b.shotNumber || 0)).map((shot) => (
                    <motion.div
                      key={shot._id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="bg-secondary p-6 rounded-lg"
                    >
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h3 className="font-heading text-xl text-primary mb-1">
                            Shot {shot.shotNumber}
                          </h3>
                          <p className="font-paragraph text-sm text-primary/70">
                            {shot.shotSize} • {shot.angle}
                          </p>
                        </div>
                        <Button
                          onClick={() => handleDelete(shot)}
                          variant="ghost"
                          size="sm"
                          className="text-destructive hover:text-destructive hover:bg-destructive/10"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>

                      <div className="space-y-2">
                        <div>
                          <span className="font-paragraph text-sm font-semibold text-primary">Movement: </span>
                          <span className="font-paragraph text-sm text-primary">{shot.movement}</span>
                        </div>
                        {shot.description && (
                          <div>
                            <span className="font-paragraph text-sm font-semibold text-primary">Description: </span>
                            <span className="font-paragraph text-sm text-primary">{shot.description}</span>
                          </div>
                        )}
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </motion.div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
