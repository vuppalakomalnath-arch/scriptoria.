// HPI 1.7-V
import React, { useRef } from 'react';
import { Link } from 'react-router-dom';
import { motion, useScroll, useTransform, useSpring } from 'framer-motion';
import { Film, Users, Clapperboard, Camera, ArrowDownRight, ArrowRight } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

// --- Canonical Data Source ---
const tools = [
  {
    id: 1,
    title: 'Script Generator',
    description: 'Create compelling film scripts with AI-powered generation tools tailored to your vision',
    icon: Film,
    link: '/script-generator',
    color: 'bg-secondary'
  },
  {
    id: 2,
    title: 'Character Generator',
    description: 'Design detailed character profiles with backstories, traits, and visual descriptions',
    icon: Users,
    link: '/character-generator',
    color: 'bg-secondary'
  },
  {
    id: 3,
    title: 'Scene Breakdown',
    description: 'Analyze and organize your script into comprehensive scene-by-scene breakdowns',
    icon: Clapperboard,
    link: '/scene-breakdown',
    color: 'bg-secondary'
  },
  {
    id: 4,
    title: 'Shot List Generator',
    description: 'Create professional shot lists with angles, movements, and technical specifications',
    icon: Camera,
    link: '/shot-list-generator',
    color: 'bg-secondary'
  }
];

// --- Components ---

const AnimatedWave = () => {
  const lineCount = 120;
  return (
    <div className="absolute inset-0 w-full h-full overflow-hidden pointer-events-none opacity-60">
      <svg width="100%" height="100%" preserveAspectRatio="none" viewBox="0 0 1200 800">
        {Array.from({ length: lineCount }).map((_, i) => {
          const x = (i / lineCount) * 1200;
          // Complex wave math for organic feel
          const wave1 = Math.sin(i * 0.05) * 150;
          const wave2 = Math.cos(i * 0.08 + 2) * 100;
          const wave3 = Math.sin(i * 0.02 + 1) * 200;
          const baseHeight = 400;
          const yTop = baseHeight - wave1 - wave2;
          const yBottom = baseHeight + wave3 + 200;

          return (
            <motion.line
              key={i}
              x1={x}
              y1={yTop}
              x2={x}
              y2={yBottom}
              stroke="currentColor"
              className="text-graphline"
              strokeWidth="1.5"
              initial={{ opacity: 0, y1: baseHeight, y2: baseHeight }}
              animate={{ opacity: 1, y1: yTop, y2: yBottom }}
              transition={{
                duration: 2,
                delay: i * 0.015,
                ease: "easeOut"
              }}
            />
          );
        })}
      </svg>
    </div>
  );
};

export default function HomePage() {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end end"]
  });

  const smoothProgress = useSpring(scrollYProgress, { damping: 20, stiffness: 100 });
  
  // Parallax transforms
  const heroY = useTransform(smoothProgress, [0, 0.2], ["0%", "20%"]);
  const heroOpacity = useTransform(smoothProgress, [0, 0.15], [1, 0]);
  const waveY = useTransform(smoothProgress, [0, 0.3], ["0%", "40%"]);

  return (
    <div ref={containerRef} className="relative min-h-screen bg-background selection:bg-primary selection:text-primary-foreground">
      <Header />

      {/* --- HERO SECTION (Inspiration Image Layout) --- */}
      <section className="relative w-full h-[100vh] min-h-[800px] overflow-hidden bg-gradient-to-br from-gradientstart to-gradientend flex flex-col justify-between pt-32 pb-12 px-6 md:px-12 lg:px-24">
        
        {/* Background Wave Motif */}
        <motion.div style={{ y: waveY }} className="absolute inset-0 z-0">
          <AnimatedWave />
        </motion.div>

        {/* Top Left: Primary Headline */}
        <motion.div 
          style={{ y: heroY, opacity: heroOpacity }}
          className="relative z-10 max-w-5xl"
        >
          <motion.h1 
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
            className="font-heading text-6xl md:text-8xl lg:text-[8rem] leading-[0.9] text-primary tracking-tight"
          >
            Your Trusted Partner in Film Production
          </motion.h1>
        </motion.div>

        {/* Bottom Right: Secondary Headline & CTA */}
        <motion.div 
          style={{ y: heroY, opacity: heroOpacity }}
          className="relative z-10 self-end max-w-2xl text-right mt-auto mb-12"
        >
          <motion.h2 
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
            className="font-heading text-4xl md:text-5xl lg:text-6xl text-primary leading-tight mb-6"
          >
            Tailored Solutions to Achieve Vision
          </motion.h2>
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 0.4 }}
            className="font-paragraph text-xl text-primary/80"
          >
            Architecting narratives with precision AI tools.
          </motion.p>
        </motion.div>

        {/* Bottom Left: Scroll Indicator (Matching Inspiration) */}
        <motion.div 
          initial={{ opacity: 0, scale: 0 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.6, type: "spring" }}
          className="absolute bottom-12 left-6 md:left-12 lg:left-24 z-20"
        >
          <div className="w-16 h-16 rounded-full bg-primary flex items-center justify-center text-primary-foreground hover:scale-110 transition-transform cursor-pointer">
            <ArrowDownRight className="w-8 h-8" />
          </div>
        </motion.div>

        {/* Decorative Dot (Matching Inspiration) */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 1 }}
          className="absolute top-1/3 right-[10%] w-3 h-3 rounded-full bg-primary z-10"
        />
      </section>

      {/* --- NARRATIVE BRIDGE --- */}
      <section className="relative w-full py-32 px-6 md:px-12 lg:px-24 bg-background z-20">
        <div className="max-w-[100rem] mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
            <div className="lg:col-span-4">
              <div className="w-full h-[1px] bg-primary/20 mb-8" />
              <h3 className="font-heading text-2xl text-primary uppercase tracking-widest">The Architecture</h3>
            </div>
            <div className="lg:col-span-8">
              <motion.p 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-100px" }}
                transition={{ duration: 0.8 }}
                className="font-paragraph text-3xl md:text-5xl text-primary leading-tight"
              >
                We transform the chaotic creative process into a structured, modular workflow. Our suite of tools provides the scaffolding for your imagination, ensuring every detail is captured, analyzed, and ready for production.
              </motion.p>
            </div>
          </div>
        </div>
      </section>

      {/* --- THE SUITE (Sticky Layout) --- */}
      <section className="relative w-full py-24 px-6 md:px-12 lg:px-24 bg-background z-20">
        <div className="max-w-[120rem] mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-start">
            
            {/* Sticky Header Column */}
            <div className="lg:col-span-5 lg:sticky lg:top-32">
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8 }}
              >
                <h2 className="font-heading text-6xl md:text-8xl text-primary mb-8 leading-none">
                  Modular<br/>Intelligence
                </h2>
                <p className="font-paragraph text-xl text-primary/70 max-w-md mb-12">
                  Select the precise instrument required for your current phase of pre-production. Each tool is designed to operate independently or as part of a cohesive ecosystem.
                </p>
                
                {/* Decorative structural element */}
                <div className="hidden lg:flex items-center gap-4 text-primary/30">
                  <div className="w-12 h-[1px] bg-current" />
                  <span className="font-heading text-sm uppercase tracking-widest">System Active</span>
                </div>
              </motion.div>
            </div>

            {/* Scrolling Cards Column */}
            <div className="lg:col-span-7 flex flex-col gap-8">
              {tools.map((tool, index) => {
                const Icon = tool.icon;
                return (
                  <motion.div
                    key={tool.id}
                    initial={{ opacity: 0, y: 50 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, margin: "-50px" }}
                    transition={{ duration: 0.6, delay: index * 0.1 }}
                  >
                    <Link to={tool.link} className="block group">
                      <div className={`relative overflow-hidden ${tool.color} p-10 md:p-16 rounded-[24px] transition-all duration-500 hover:-translate-y-2 hover:shadow-2xl`}>
                        
                        {/* Card Background Motif */}
                        <div className="absolute top-0 right-0 w-64 h-64 bg-background/20 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2 group-hover:scale-150 transition-transform duration-700" />
                        
                        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-8">
                          <div className="flex-1">
                            <div className="w-16 h-16 rounded-full bg-primary flex items-center justify-center mb-8 group-hover:scale-110 transition-transform duration-500">
                              <Icon className="w-8 h-8 text-secondary" />
                            </div>
                            <h3 className="font-heading text-4xl md:text-5xl text-primary mb-4">
                              {tool.title}
                            </h3>
                            <p className="font-paragraph text-lg text-primary/80 max-w-md">
                              {tool.description}
                            </p>
                          </div>
                          
                          <div className="w-12 h-12 rounded-full border-2 border-primary flex items-center justify-center shrink-0 group-hover:bg-primary group-hover:text-secondary transition-colors duration-300">
                            <ArrowRight className="w-6 h-6" />
                          </div>
                        </div>
                      </div>
                    </Link>
                  </motion.div>
                );
              })}
            </div>

          </div>
        </div>
      </section>

      {/* --- METRICS / IMPACT --- */}
      <section className="relative w-full py-32 px-6 md:px-12 lg:px-24 bg-primary text-primary-foreground overflow-hidden">
        {/* Subtle background texture */}
        <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)', backgroundSize: '32px 32px' }} />
        
        <div className="relative z-10 max-w-[120rem] mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 md:gap-8 divide-y md:divide-y-0 md:divide-x divide-primary-foreground/20">
            {[
              { number: '1000+', label: 'Scripts Generated' },
              { number: '5000+', label: 'Characters Created' },
              { number: '10000+', label: 'Scenes Analyzed' }
            ].map((stat, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
                className="pt-8 md:pt-0 md:px-12 first:md:pl-0 last:md:pr-0 flex flex-col justify-center"
              >
                <div className="font-heading text-6xl md:text-7xl lg:text-8xl mb-4 tracking-tighter">
                  {stat.number}
                </div>
                <div className="font-paragraph text-xl text-primary-foreground/70 uppercase tracking-widest">
                  {stat.label}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* --- FINAL CTA --- */}
      <section className="relative w-full py-40 px-6 md:px-12 lg:px-24 bg-gradient-to-t from-gradientstart/30 to-background text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="max-w-4xl mx-auto"
        >
          <h2 className="font-heading text-5xl md:text-7xl text-primary mb-8">
            Ready to Architect Your Next Masterpiece?
          </h2>
          <p className="font-paragraph text-xl text-primary/70 mb-12">
            Join the vanguard of creators utilizing structured AI to elevate their pre-production workflow.
          </p>
          <Link to="/script-generator" className="inline-flex items-center justify-center px-12 py-6 bg-primary text-primary-foreground font-heading text-xl rounded-full hover:scale-105 transition-transform duration-300">
            Initialize System
          </Link>
        </motion.div>
      </section>

      <Footer />
    </div>
  );
}