import { useState } from 'react';
import { motion } from 'framer-motion';
import { Clapperboard, Sparkles, Plus, Trash2 } from 'lucide-react';
import { BaseCrudService } from '@/integrations';
import { SceneBreakdowns } from '@/entities';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { LoadingSpinner } from '@/components/ui/loading-spinner';

export default function SceneBreakdownPage() {
  const [sceneNumber, setSceneNumber] = useState('');
  const [sceneTitle, setSceneTitle] = useState('');
  const [location, setLocation] = useState('');
  const [timeOfDay, setTimeOfDay] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [scenes, setScenes] = useState<SceneBreakdowns[]>([]);

  const handleGenerate = async () => {
    if (!sceneNumber || !sceneTitle || !location) {
      return;
    }

    setIsGenerating(true);

    const charactersInvolved = 'Protagonist, Supporting Character';
    const props = 'Essential items that serve the narrative and enhance the scene\'s authenticity';
    const sceneSummary = `Scene ${sceneNumber} establishes critical story elements through visual storytelling and character interaction. The ${location} setting provides the perfect backdrop for advancing the plot and deepening character relationships.`;

    try {
      const newScene: SceneBreakdowns = {
        _id: crypto.randomUUID(),
        sceneNumber: parseInt(sceneNumber),
        sceneTitle,
        location,
        timeOfDay: timeOfDay || 'Day',
        charactersInvolved,
        props,
        sceneSummary,
        _createdDate: new Date(),
        _updatedDate: new Date()
      };

      await BaseCrudService.create('scenebreakdowns', newScene);
      setScenes([...scenes, newScene]);
      
      setSceneNumber('');
      setSceneTitle('');
      setLocation('');
      setTimeOfDay('');
    } catch (error) {
      console.error('Error creating scene breakdown:', error);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDelete = async (scene: SceneBreakdowns) => {
    setScenes(scenes.filter(s => s._id !== scene._id));
    try {
      await BaseCrudService.delete('scenebreakdowns', scene._id);
    } catch (error) {
      console.error('Error deleting scene:', error);
      const allScenes = await BaseCrudService.getAll<SceneBreakdowns>('scenebreakdowns');
      setScenes(allScenes.items);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gradientstart to-gradientend">
      <Header />
      
      <main className="pt-24 pb-16">
        <div className="max-w-[100rem] mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="mb-12"
          >
            <div className="flex items-center gap-3 mb-4">
              <Clapperboard className="w-10 h-10 text-primary" />
              <h1 className="font-heading text-5xl text-primary">Scene Breakdown</h1>
            </div>
            <p className="font-paragraph text-lg text-primary max-w-3xl">
              Analyze and organize your script into comprehensive scene-by-scene breakdowns with all production details.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="lg:col-span-2 bg-background p-8 rounded-lg h-fit"
            >
              <h2 className="font-heading text-2xl text-primary mb-6">Add Scene</h2>
              
              <div className="space-y-6">
                <div>
                  <Label htmlFor="sceneNumber" className="font-paragraph text-base text-primary mb-2 block">
                    Scene Number *
                  </Label>
                  <Input
                    id="sceneNumber"
                    type="number"
                    value={sceneNumber}
                    onChange={(e) => setSceneNumber(e.target.value)}
                    placeholder="e.g., 1"
                    className="w-full"
                  />
                </div>

                <div>
                  <Label htmlFor="sceneTitle" className="font-paragraph text-base text-primary mb-2 block">
                    Scene Title *
                  </Label>
                  <Input
                    id="sceneTitle"
                    value={sceneTitle}
                    onChange={(e) => setSceneTitle(e.target.value)}
                    placeholder="e.g., The Opening Confrontation"
                    className="w-full"
                  />
                </div>

                <div>
                  <Label htmlFor="location" className="font-paragraph text-base text-primary mb-2 block">
                    Location *
                  </Label>
                  <Input
                    id="location"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    placeholder="e.g., INT. OFFICE - DAY"
                    className="w-full"
                  />
                </div>

                <div>
                  <Label htmlFor="timeOfDay" className="font-paragraph text-base text-primary mb-2 block">
                    Time of Day (Optional)
                  </Label>
                  <Input
                    id="timeOfDay"
                    value={timeOfDay}
                    onChange={(e) => setTimeOfDay(e.target.value)}
                    placeholder="e.g., Day, Night, Dawn"
                    className="w-full"
                  />
                </div>

                <Button
                  onClick={handleGenerate}
                  disabled={!sceneNumber || !sceneTitle || !location || isGenerating}
                  className="w-full bg-secondary text-primary hover:bg-secondary/90"
                >
                  {isGenerating ? (
                    <>
                      <LoadingSpinner className="w-4 h-4 mr-2" />
                      Adding...
                    </>
                  ) : (
                    <>
                      <Plus className="w-4 h-4 mr-2" />
                      Add Scene
                    </>
                  )}
                </Button>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="lg:col-span-3 bg-background p-8 rounded-lg min-h-[600px]"
            >
              <h2 className="font-heading text-2xl text-primary mb-6">Scene List</h2>
              
              {scenes.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-96 text-center">
                  <Clapperboard className="w-16 h-16 text-primary/30 mb-4" />
                  <p className="font-paragraph text-base text-primary/60">
                    No scenes yet. Add your first scene to get started.
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {scenes.sort((a, b) => (a.sceneNumber || 0) - (b.sceneNumber || 0)).map((scene) => (
                    <motion.div
                      key={scene._id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="bg-secondary p-6 rounded-lg"
                    >
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h3 className="font-heading text-xl text-primary mb-1">
                            Scene {scene.sceneNumber}: {scene.sceneTitle}
                          </h3>
                          <p className="font-paragraph text-sm text-primary/70">
                            {scene.location} • {scene.timeOfDay}
                          </p>
                        </div>
                        <Button
                          onClick={() => handleDelete(scene)}
                          variant="ghost"
                          size="sm"
                          className="text-destructive hover:text-destructive hover:bg-destructive/10"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>

                      <div className="space-y-2">
                        <div>
                          <span className="font-paragraph text-sm font-semibold text-primary">Characters: </span>
                          <span className="font-paragraph text-sm text-primary">{scene.charactersInvolved}</span>
                        </div>
                        <div>
                          <span className="font-paragraph text-sm font-semibold text-primary">Props: </span>
                          <span className="font-paragraph text-sm text-primary">{scene.props}</span>
                        </div>
                        <div>
                          <span className="font-paragraph text-sm font-semibold text-primary">Summary: </span>
                          <span className="font-paragraph text-sm text-primary">{scene.sceneSummary}</span>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </motion.div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
