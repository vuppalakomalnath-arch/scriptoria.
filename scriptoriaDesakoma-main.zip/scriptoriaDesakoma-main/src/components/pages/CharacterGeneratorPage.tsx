import { useState } from 'react';
import { motion } from 'framer-motion';
import { Users, Sparkles } from 'lucide-react';
import { BaseCrudService } from '@/integrations';
import { Characters } from '@/entities';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { LoadingSpinner } from '@/components/ui/loading-spinner';
import { Image } from '@/components/ui/image';

export default function CharacterGeneratorPage() {
  const [characterName, setCharacterName] = useState('');
  const [roleInStory, setRoleInStory] = useState('');
  const [characterTraits, setCharacterTraits] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedCharacter, setGeneratedCharacter] = useState<Characters | null>(null);

  const handleGenerate = async () => {
    if (!characterName || !roleInStory) {
      return;
    }

    setIsGenerating(true);

    const backstory = `${characterName} grew up in circumstances that shaped their unique perspective on life. Their journey has been marked by pivotal moments that forged their character and defined their purpose. Through trials and triumphs, they developed the qualities that make them essential to this story.`;

    const appearance = `${characterName} possesses a distinctive presence that reflects their inner nature. Their physical characteristics and mannerisms reveal the depth of their experiences and the strength of their convictions.`;

    try {
      const newCharacter: Characters = {
        _id: crypto.randomUUID(),
        characterName,
        roleInStory,
        characterTraits: characterTraits || 'Determined, complex, authentic',
        backstory,
        appearance,
        characterImage: 'https://static.wixstatic.com/media/d8a3c4_1014de34a4c144f8b7ace6d3507cc84f~mv2.png?originWidth=576&originHeight=320',
        _createdDate: new Date(),
        _updatedDate: new Date()
      };

      await BaseCrudService.create('characters', newCharacter);
      setGeneratedCharacter(newCharacter);
    } catch (error) {
      console.error('Error generating character:', error);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleReset = () => {
    setCharacterName('');
    setRoleInStory('');
    setCharacterTraits('');
    setGeneratedCharacter(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gradientstart to-gradientend">
      <Header />
      
      <main className="pt-24 pb-16">
        <div className="max-w-[100rem] mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="mb-12"
          >
            <div className="flex items-center gap-3 mb-4">
              <Users className="w-10 h-10 text-primary" />
              <h1 className="font-heading text-5xl text-primary">Character Generator</h1>
            </div>
            <p className="font-paragraph text-lg text-primary max-w-3xl">
              Design detailed character profiles with rich backstories, traits, and visual descriptions for your film.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="bg-background p-8 rounded-lg"
            >
              <h2 className="font-heading text-2xl text-primary mb-6">Character Details</h2>
              
              <div className="space-y-6">
                <div>
                  <Label htmlFor="characterName" className="font-paragraph text-base text-primary mb-2 block">
                    Character Name *
                  </Label>
                  <Input
                    id="characterName"
                    value={characterName}
                    onChange={(e) => setCharacterName(e.target.value)}
                    placeholder="Enter character name"
                    className="w-full"
                  />
                </div>

                <div>
                  <Label htmlFor="roleInStory" className="font-paragraph text-base text-primary mb-2 block">
                    Role in Story *
                  </Label>
                  <Input
                    id="roleInStory"
                    value={roleInStory}
                    onChange={(e) => setRoleInStory(e.target.value)}
                    placeholder="e.g., Protagonist, Antagonist, Supporting"
                    className="w-full"
                  />
                </div>

                <div>
                  <Label htmlFor="characterTraits" className="font-paragraph text-base text-primary mb-2 block">
                    Character Traits (Optional)
                  </Label>
                  <Textarea
                    id="characterTraits"
                    value={characterTraits}
                    onChange={(e) => setCharacterTraits(e.target.value)}
                    placeholder="e.g., Brave, intelligent, conflicted"
                    className="w-full min-h-24"
                  />
                </div>

                <div className="flex gap-4">
                  <Button
                    onClick={handleGenerate}
                    disabled={!characterName || !roleInStory || isGenerating}
                    className="flex-1 bg-secondary text-primary hover:bg-secondary/90"
                  >
                    {isGenerating ? (
                      <>
                        <LoadingSpinner className="w-4 h-4 mr-2" />
                        Generating...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-4 h-4 mr-2" />
                        Generate Character
                      </>
                    )}
                  </Button>
                  
                  {generatedCharacter && (
                    <Button
                      onClick={handleReset}
                      variant="outline"
                      className="border-primary text-primary hover:bg-primary/10"
                    >
                      Reset
                    </Button>
                  )}
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="bg-background p-8 rounded-lg min-h-[600px]"
            >
              <h2 className="font-heading text-2xl text-primary mb-6">Character Profile</h2>
              
              {isGenerating ? (
                <div className="flex items-center justify-center h-96">
                  <LoadingSpinner className="w-12 h-12 text-primary" />
                </div>
              ) : generatedCharacter ? (
                <div className="space-y-6">
                  <div className="aspect-video w-full bg-primary/5 rounded-lg overflow-hidden">
                    <Image
                      src={generatedCharacter.characterImage || ''}
                      alt={generatedCharacter.characterName || 'Character'}
                      width={600}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  
                  <div>
                    <h3 className="font-heading text-2xl text-primary mb-2">
                      {generatedCharacter.characterName}
                    </h3>
                    <p className="font-paragraph text-base text-primary/70 mb-4">
                      Role: {generatedCharacter.roleInStory}
                    </p>
                  </div>

                  <div>
                    <h4 className="font-heading text-lg text-primary mb-2">Traits</h4>
                    <p className="font-paragraph text-base text-primary">
                      {generatedCharacter.characterTraits}
                    </p>
                  </div>

                  <div>
                    <h4 className="font-heading text-lg text-primary mb-2">Backstory</h4>
                    <p className="font-paragraph text-base text-primary">
                      {generatedCharacter.backstory}
                    </p>
                  </div>

                  <div>
                    <h4 className="font-heading text-lg text-primary mb-2">Appearance</h4>
                    <p className="font-paragraph text-base text-primary">
                      {generatedCharacter.appearance}
                    </p>
                  </div>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center h-96 text-center">
                  <Users className="w-16 h-16 text-primary/30 mb-4" />
                  <p className="font-paragraph text-base text-primary/60">
                    Fill in the details and click Generate to create your character
                  </p>
                </div>
              )}
            </motion.div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
