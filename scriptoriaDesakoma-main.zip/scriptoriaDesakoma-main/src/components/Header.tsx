import { Link, useLocation } from 'react-router-dom';
import { Film } from 'lucide-react';

export default function Header() {
  const location = useLocation();
  
  const navLinks = [
    { path: '/', label: 'Home' },
    { path: '/script-generator', label: 'Scripts' },
    { path: '/character-generator', label: 'Characters' },
    { path: '/scene-breakdown', label: 'Scenes' },
    { path: '/shot-list-generator', label: 'Shot Lists' }
  ];

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-background/95 backdrop-blur-sm border-b border-primary/10">
      <div className="max-w-[100rem] mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <Film className="w-8 h-8 text-primary" />
            <span className="font-heading text-2xl text-primary">FilmAI</span>
          </Link>

          <nav className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`font-paragraph text-base transition-colors ${
                  location.pathname === link.path
                    ? 'text-primary font-semibold'
                    : 'text-primary/70 hover:text-primary'
                }`}
              >
                {link.label}
              </Link>
            ))}
          </nav>

          <Link
            to="/script-generator"
            className="bg-secondary text-primary font-paragraph text-base px-6 py-2 rounded-lg hover:scale-105 transition-transform"
          >
            Get Started
          </Link>
        </div>
      </div>
    </header>
  );
}
