import { MemberProvider } from '@/integrations';
import { createBrowserRouter, RouterProvider, Navigate, Outlet } from 'react-router-dom';
import { ScrollToTop } from '@/lib/scroll-to-top';
import ErrorPage from '@/integrations/errorHandlers/ErrorPage';
import HomePage from '@/components/pages/HomePage';
import ScriptGeneratorPage from '@/components/pages/ScriptGeneratorPage';
import CharacterGeneratorPage from '@/components/pages/CharacterGeneratorPage';
import SceneBreakdownPage from '@/components/pages/SceneBreakdownPage';
import ShotListGeneratorPage from '@/components/pages/ShotListGeneratorPage';

// Layout component that includes ScrollToTop
function Layout() {
  return (
    <>
      <ScrollToTop />
      <Outlet />
    </>
  );
}

const router = createBrowserRouter([
  {
    path: "/",
    element: <Layout />,
    errorElement: <ErrorPage />,
    children: [
      {
        index: true,
        element: <HomePage />,
        routeMetadata: {
          pageIdentifier: 'home',
        },
      },
      {
        path: "script-generator",
        element: <ScriptGeneratorPage />,
        routeMetadata: {
          pageIdentifier: 'script-generator',
        },
      },
      {
        path: "character-generator",
        element: <CharacterGeneratorPage />,
        routeMetadata: {
          pageIdentifier: 'character-generator',
        },
      },
      {
        path: "scene-breakdown",
        element: <SceneBreakdownPage />,
        routeMetadata: {
          pageIdentifier: 'scene-breakdown',
        },
      },
      {
        path: "shot-list-generator",
        element: <ShotListGeneratorPage />,
        routeMetadata: {
          pageIdentifier: 'shot-list-generator',
        },
      },
      {
        path: "*",
        element: <Navigate to="/" replace />,
      },
    ],
  },
], {
  basename: import.meta.env.BASE_NAME,
});

export default function AppRouter() {
  return (
    <MemberProvider>
      <RouterProvider router={router} />
    </MemberProvider>
  );
}
