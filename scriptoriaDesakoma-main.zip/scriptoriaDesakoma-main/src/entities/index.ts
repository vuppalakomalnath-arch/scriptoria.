/**
 * Auto-generated entity types
 * Contains all CMS collection interfaces in a single file 
 */

/**
 * Collection ID: characters
 * Interface for Characters
 */
export interface Characters {
  _id: string;
  _createdDate?: Date;
  _updatedDate?: Date;
  /** @wixFieldType text */
  characterName?: string;
  /** @wixFieldType text */
  characterTraits?: string;
  /** @wixFieldType text */
  backstory?: string;
  /** @wixFieldType text */
  appearance?: string;
  /** @wixFieldType image - Contains image URL, render with <Image> component, NOT as text */
  characterImage?: string;
  /** @wixFieldType text */
  roleInStory?: string;
}


/**
 * Collection ID: scenebreakdowns
 * Interface for SceneBreakdowns
 */
export interface SceneBreakdowns {
  _id: string;
  _createdDate?: Date;
  _updatedDate?: Date;
  /** @wixFieldType number */
  sceneNumber?: number;
  /** @wixFieldType text */
  sceneTitle?: string;
  /** @wixFieldType text */
  location?: string;
  /** @wixFieldType text */
  charactersInvolved?: string;
  /** @wixFieldType text */
  props?: string;
  /** @wixFieldType text */
  sceneSummary?: string;
  /** @wixFieldType text */
  timeOfDay?: string;
}


/**
 * Collection ID: scripts
 * Interface for Scripts
 */
export interface Scripts {
  _id: string;
  _createdDate?: Date;
  _updatedDate?: Date;
  /** @wixFieldType text */
  title?: string;
  /** @wixFieldType text */
  content?: string;
  /** @wixFieldType text */
  genre?: string;
  /** @wixFieldType text */
  logline?: string;
  /** @wixFieldType text */
  synopsis?: string;
}


/**
 * Collection ID: shotlists
 * Interface for ShotLists
 */
export interface ShotLists {
  _id: string;
  _createdDate?: Date;
  _updatedDate?: Date;
  /** @wixFieldType number */
  shotNumber?: number;
  /** @wixFieldType text */
  angle?: string;
  /** @wixFieldType text */
  shotSize?: string;
  /** @wixFieldType text */
  movement?: string;
  /** @wixFieldType text */
  description?: string;
}
